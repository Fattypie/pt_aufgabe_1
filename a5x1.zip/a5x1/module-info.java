module DXE_CardsInReverseOrder_Distr {
}//module