module DXF_CardComparator_Distr {
}//module